import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CustomTextStyle {
  static TextStyle kstyle1() {
    return TextStyle(
        fontSize: 12, fontWeight: FontWeight.w400, color: Colors.black);
  }
}